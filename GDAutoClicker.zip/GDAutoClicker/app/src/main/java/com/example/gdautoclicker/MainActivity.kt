package com.example.gdautoclicker

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0F1A)
private val Card = Color(0xFF141A2B)
private val Accent = Color(0xFF6C5CE7)
private val Accent2 = Color(0xFF00D2FF)
private val Muted = Color(0xFF9AA4BF)
private val Ok = Color(0xFF2ECC71)
private val Warn = Color(0xFFFFB020)

class MainActivity : ComponentActivity() {
    private val serviceOn = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)) {
                App(serviceOn.value)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        serviceOn.value = ClickerService.instance != null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(serviceOn: Boolean) {
    val ctx = LocalContext.current
    val store = remember { PatternStore(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Level?>(null) }
    var refresh by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
        Header()
        PermissionCard(serviceOn) {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        TabRow(
            selectedTabIndex = tab,
            containerColor = Color.Transparent,
            contentColor = Accent2
        ) {
            Levels.groups.forEachIndexed { i, g ->
                Tab(selected = tab == i, onClick = { tab = i }, text = { Text(g) })
            }
        }
        val list = Levels.all.filter { it.group == Levels.groups[tab] }
        LazyColumn(
            Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(list, key = { it.id }) { level ->
                @Suppress("UNUSED_EXPRESSION") refresh
                LevelRow(level, store.hasMacro(level.id)) { selected = level }
            }
        }
    }

    selected?.let { level ->
        ModalBottomSheet(
            onDismissRequest = { selected = null; refresh++ },
            containerColor = Card
        ) {
            Editor(level, store, serviceOn) { selected = null; refresh++ }
        }
    }
}

@Composable
private fun Header() {
    Box(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Accent, Accent2)))
            .padding(horizontal = 20.dp, vertical = 22.dp)
    ) {
        Column {
            Text("GD AutoClicker", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Шаблоны нажатий для каждого уровня", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun PermissionCard(serviceOn: Boolean, openSettings: () -> Unit) {
    val color = if (serviceOn) Ok else Warn
    Row(
        Modifier.padding(16.dp).fillMaxWidth()
            .clip(RoundedCornerShape(16.dp)).background(Card)
            .clickable(enabled = !serviceOn) { openSettings() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(if (serviceOn) Icons.Default.CheckCircle else Icons.Default.Warning, null, tint = color)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                if (serviceOn) "Служба доступности включена" else "Нужно включить службу доступности",
                color = Color.White, fontWeight = FontWeight.SemiBold
            )
            Text(
                if (serviceOn) "Нажатия и панель поверх игры доступны"
                else "Настройки → Специальные возможности → GD AutoClicker. Это единственное разрешение приложения.",
                color = Muted, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun LevelRow(level: Level, hasMacro: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(36.dp).clip(CircleShape).background(Accent.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.PlayArrow, null, tint = Accent2) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(level.name, color = Color.White, fontWeight = FontWeight.Medium)
            Text(if (hasMacro) "Записан макрос" else "Базовый шаблон", color = if (hasMacro) Ok else Muted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun Editor(level: Level, store: PatternStore, serviceOn: Boolean, close: () -> Unit) {
    val ctx = LocalContext.current
    val initial = remember(level.id) { store.get(level.id) }
    var mode by remember { mutableStateOf(initial.mode) }
    var interval by remember { mutableFloatStateOf(initial.intervalMs.toFloat()) }
    var hold by remember { mutableFloatStateOf(initial.holdMs.toFloat()) }
    var loop by remember { mutableStateOf(initial.loop) }
    var taps by remember { mutableStateOf(initial.taps) }
    var recStart by remember { mutableLongStateOf(0L) }

    fun current() = Pattern(mode, interval.toLong(), hold.toLong(), loop, taps)

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(level.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(mode == Mode.INTERVAL, { mode = Mode.INTERVAL }, { Text("Интервал") })
            FilterChip(mode == Mode.MACRO, { mode = Mode.MACRO }, { Text("Макрос") })
        }

        if (mode == Mode.INTERVAL) {
            Text("Интервал между нажатиями: ${interval.toInt()} мс", color = Muted)
            Slider(interval, { interval = it }, valueRange = 40f..1500f)
            Text("Удержание: ${hold.toInt()} мс", color = Muted)
            Slider(hold, { hold = it }, valueRange = 10f..600f)
        } else {
            Text(
                "Включите музыку/уровень и повторите прохождение нажатиями на площадку ниже. " +
                    "Записано нажатий: ${taps.size}",
                color = Muted, fontSize = 13.sp
            )
            Box(
                Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.verticalGradient(listOf(Accent.copy(alpha = 0.35f), Card)))
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            val down = SystemClock.uptimeMillis()
                            if (taps.isEmpty()) recStart = down
                            tryAwaitRelease()
                            val up = SystemClock.uptimeMillis()
                            taps = taps + Tap(down - recStart, (up - down).coerceAtLeast(1))
                        })
                    },
                contentAlignment = Alignment.Center
            ) { Text("Нажимайте здесь в ритме уровня", color = Color.White) }
            OutlinedButton(onClick = { taps = emptyList() }, border = BorderStroke(1.dp, Muted)) {
                Text("Очистить запись", color = Muted)
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(loop, { loop = it })
            Spacer(Modifier.width(10.dp))
            Text("Повторять по кругу", color = Color.White)
        }

        Button(
            onClick = {
                store.put(level.id, current())
                val svc = ClickerService.instance
                if (svc == null) {
                    Toast.makeText(ctx, "Сначала включите службу доступности", Toast.LENGTH_LONG).show()
                } else {
                    svc.showPanel(level.name, current())
                    val intent = ctx.packageManager.getLaunchIntentForPackage("com.robtopx.geometryjump")
                    if (intent != null) ctx.startActivity(intent)
                    else Toast.makeText(ctx, "Geometry Dash не найдена, панель показана поверх других приложений", Toast.LENGTH_LONG).show()
                    close()
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Accent),
            shape = RoundedCornerShape(14.dp)
        ) { Text("Открыть игру с панелью") }

        TextButton(
            onClick = { store.put(level.id, current()); close() },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Сохранить шаблон", color = Accent2) }
    }
}
