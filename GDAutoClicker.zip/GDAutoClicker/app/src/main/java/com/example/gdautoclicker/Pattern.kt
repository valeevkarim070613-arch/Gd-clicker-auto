package com.example.gdautoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Одно нажатие макроса: через atMs от старта, удержание holdMs. */
data class Tap(val atMs: Long, val holdMs: Long)

enum class Mode { INTERVAL, MACRO }

data class Pattern(
    val mode: Mode = Mode.INTERVAL,
    val intervalMs: Long = 400,
    val holdMs: Long = 40,
    val loop: Boolean = false,
    val taps: List<Tap> = emptyList()
)

/** Хранит шаблон нажатий для каждого уровня в приватных SharedPreferences. */
class PatternStore(context: Context) {
    private val prefs = context.getSharedPreferences("patterns", Context.MODE_PRIVATE)

    fun get(levelId: String): Pattern {
        val raw = prefs.getString(levelId, null) ?: return Pattern()
        return try {
            val o = JSONObject(raw)
            val arr = o.optJSONArray("taps") ?: JSONArray()
            Pattern(
                mode = Mode.valueOf(o.optString("mode", "INTERVAL")),
                intervalMs = o.optLong("interval", 400),
                holdMs = o.optLong("hold", 40),
                loop = o.optBoolean("loop", false),
                taps = List(arr.length()) {
                    val t = arr.getJSONArray(it)
                    Tap(t.getLong(0), t.getLong(1))
                }
            )
        } catch (e: Exception) {
            Pattern()
        }
    }

    fun put(levelId: String, p: Pattern) {
        val o = JSONObject()
            .put("mode", p.mode.name)
            .put("interval", p.intervalMs)
            .put("hold", p.holdMs)
            .put("loop", p.loop)
            .put("taps", JSONArray().also { a ->
                p.taps.forEach { a.put(JSONArray().put(it.atMs).put(it.holdMs)) }
            })
        prefs.edit().putString(levelId, o.toString()).apply()
    }

    fun hasMacro(levelId: String) = get(levelId).taps.isNotEmpty()
}
